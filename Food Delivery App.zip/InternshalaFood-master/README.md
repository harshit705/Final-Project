## Internshala App-a-thon Challenge
I won 🏅 third prize 🏆 for this project
This app is Demo Solution of the Android App Challenge 😎

### ScreenShots

![1st](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084137.png)
![2nd](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084141.png)
![3rd](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084155.png)
![4th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084205.png)
![5th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084220.png)
![6th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084238.png)
![7th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084251.png)
![8th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084308.png)
![9th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084314.png)
![10th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084318.png)
![11th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084324.png)
![12th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084335.png)
![13th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084343.png)
![14th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084349.png)
![15th](https://raw.githubusercontent.com/sahuadarsh0/InternshalaFood/master/ScreenShots/Screenshot_20210803-084555.png)
